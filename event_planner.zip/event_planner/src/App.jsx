import EventPlanner from "./Components/EventPlanner.jsx";
import './App.css'

function App() {
  return (
    <>
      <EventPlanner/>
    </>
  )
}

export default App
