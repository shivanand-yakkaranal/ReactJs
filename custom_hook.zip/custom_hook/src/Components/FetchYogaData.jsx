import React from 'react';
import UseFetch from './UseFetch';
import useFetch from "./UseFetch";
const FetchYogaData = () => {
    const [data] = useFetch('https://api.npoint.io/4459a9a10e43812e1152');
    console.log(data);
    return(
        <>
            <h1 className='usefetch_heading'>Use Fetch Custom Hook</h1>
            <ul>
                {data && data.map(e => (
                        <li className='list_data'>

                            <h3>Name: {e.name}</h3>
                            <p><strong>Benefits: {e.benefits}</strong></p>
                            <p><strong>Time duration: {e.time_duration}</strong></p>
                        </li>

                    )
                )}
            </ul>
        </>
    );
};
export default FetchYogaData;